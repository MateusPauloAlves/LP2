﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pma
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnExcute_Click(object sender, EventArgs e)
        {
            string nome1, nome2, nome3;

            nome1 = Interaction.InputBox("Digite os nomes", "Entrada de nomes");
            nome2 = Interaction.InputBox("Digite os nomes", "Entrada de nomes");
            nome3 = Interaction.InputBox("Digite os nomes", "Entrada de nomes");

            int QntCarac = 0;
            char[] arr = nome1.ToCharArray();
            char[] arr2 = nome2.ToCharArray();
            char[] arr3 = nome3.ToCharArray();


            for (int i = 0; i < arr.Length; i++)
            {
                if (char.IsLetterOrDigit(arr[i]))
                    QntCarac++;
            }
            lbxNomes.Items.Add("O nome " + nome1 + " tem " + QntCarac + " caracteres.\n");

            QntCarac = 0;
            for (int i = 0; i < arr2.Length; i++)
            {
                if (char.IsLetterOrDigit(arr2[i]))
                    QntCarac++;
            }
            lbxNomes.Items.Add("O nome " + nome2 + " tem " + QntCarac + " caracteres.\n");

            QntCarac = 0;
            for (int i = 0; i < arr3.Length; i++)
            {
                if (char.IsLetterOrDigit(arr3[i]))
                    QntCarac++;
            }
            lbxNomes.Items.Add("O nome " + nome3 + " tem " + QntCarac + " caracteres.\n");
        }
    }
}
