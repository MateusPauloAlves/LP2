﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pma
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLerInverte_Click(object sender, EventArgs e)
        {
            int[] NumInver = new int[20];
            string aux;

            for (int i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox("Digite números", "Entrada de dados");

                if (!Int32.TryParse(aux, out NumInver[i]))
                {
                    MessageBox.Show("Dado inválido");
                    i--;
                }
            }

            aux = "";
            for (int i = 19; i > 0; i--)
            {
                aux = aux + NumInver[i] + "\n";
            }
            MessageBox.Show(aux);
        }

        private void btnLerQuantPreMerca_Click(object sender, EventArgs e)
        {
            double faturamento = 0;
            double[] Qtde = new double[10];
            double[] VLR = new double[10];
            string aux = "";

            for(var i = 0; i < 10; i++){
                aux = Interaction.InputBox("Digite quantidade de mercadoria" + (i + 1), "Entrada de quantidades");

                if (!double.TryParse(aux, out Qtde[i]))
                {
                    MessageBox.Show("Quantidade inválida");
                    i--;
                }
                else
                {
                    while (VLR[i] <= 0)
                    {
                        aux = "";
                        aux = Interaction.InputBox("Digite o valor da mercadoria" + (i + 1), "Entrada de preços");

                        if (double.TryParse(aux, out VLR[i]))
                        {
                            MessageBox.Show("Preço Inválido");
                        }
                    }
                }
                faturamento += Qtde[i] * VLR[i];
            }
            MessageBox.Show(faturamento.ToString("N2"));
          }

        private void btnVarialvelTotal_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };
            Int32 I, Total = 0; 
            Int32 N = Alunos.Length; 

            for (I = 0; I < N - 1; I++) { 
                Total += Alunos[I].Length;
                MessageBox.Show("O tamanho é " + Total);
            }
            
        }

        private void btnMediaAlunos_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20,3];
            string aux;
            int i, j;

            for ( i = 0; i < 20; i++)
            {
                for ( j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox("Digite a nota" + (j + 1) + "do aluno" + (i + 1), "Entrada de dados");

                    if (!double.TryParse(aux, out notas[i,j]))
                    {
                        MessageBox.Show("Nota inválida");
                        j--;
                    }
                    else
                    {
                        if (notas[i, j] >= 0 && notas[i, j] <= 10)
                        {
                            MessageBox.Show("nota inválida");
                            j--;
                        }
                    }
                }
               double media = (notas[i, 0] + notas[i, 1] + notas[i, 2])/3;
               MessageBox.Show("aluno" + (i+1) + "teve média " + media.ToString("N2"));
            }
        }

        private void btnArray_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList(); // tipo string
            lista.Add("Ana");
            lista.Add("André");
            lista.Add("Débora");
            lista.Add("Fátima");
            lista.Add("João");
            lista.Add("Janete");
            //lista.Add("Otávio");
            lista.Add("Marcelo");
            lista.Add("Pedro");
            lista.Add("Thais");

            object[] obj1 = lista.ToArray();

            foreach ( string st in obj1)
            {
                MessageBox.Show(st);
            }
        }

        private void btnNomesPessoas_Click(object sender, EventArgs e)
        { 
            Form2 _f2;
            _f2 = new Form2();
            _f2.Show();
        }
    }
}