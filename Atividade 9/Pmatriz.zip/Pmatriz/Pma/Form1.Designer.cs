﻿namespace Pma
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNomesPessoas = new System.Windows.Forms.Button();
            this.btnVarialvelTotal = new System.Windows.Forms.Button();
            this.btnMediaAlunos = new System.Windows.Forms.Button();
            this.btnLerQuantPreMerca = new System.Windows.Forms.Button();
            this.btnArray = new System.Windows.Forms.Button();
            this.btnLerInverte = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnNomesPessoas
            // 
            this.btnNomesPessoas.Location = new System.Drawing.Point(624, 284);
            this.btnNomesPessoas.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNomesPessoas.Name = "btnNomesPessoas";
            this.btnNomesPessoas.Size = new System.Drawing.Size(131, 76);
            this.btnNomesPessoas.TabIndex = 11;
            this.btnNomesPessoas.Text = "Nomes Pessoas";
            this.btnNomesPessoas.UseVisualStyleBackColor = true;
            this.btnNomesPessoas.Click += new System.EventHandler(this.btnNomesPessoas_Click);
            // 
            // btnVarialvelTotal
            // 
            this.btnVarialvelTotal.Location = new System.Drawing.Point(624, 133);
            this.btnVarialvelTotal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnVarialvelTotal.Name = "btnVarialvelTotal";
            this.btnVarialvelTotal.Size = new System.Drawing.Size(131, 71);
            this.btnVarialvelTotal.TabIndex = 10;
            this.btnVarialvelTotal.Text = "Variável Total";
            this.btnVarialvelTotal.UseVisualStyleBackColor = true;
            this.btnVarialvelTotal.Click += new System.EventHandler(this.btnVarialvelTotal_Click);
            // 
            // btnMediaAlunos
            // 
            this.btnMediaAlunos.Location = new System.Drawing.Point(376, 284);
            this.btnMediaAlunos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMediaAlunos.Name = "btnMediaAlunos";
            this.btnMediaAlunos.Size = new System.Drawing.Size(181, 76);
            this.btnMediaAlunos.TabIndex = 9;
            this.btnMediaAlunos.Text = "Média Alunos";
            this.btnMediaAlunos.UseVisualStyleBackColor = true;
            this.btnMediaAlunos.Click += new System.EventHandler(this.btnMediaAlunos_Click);
            // 
            // btnLerQuantPreMerca
            // 
            this.btnLerQuantPreMerca.Location = new System.Drawing.Point(376, 133);
            this.btnLerQuantPreMerca.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLerQuantPreMerca.Name = "btnLerQuantPreMerca";
            this.btnLerQuantPreMerca.Size = new System.Drawing.Size(181, 71);
            this.btnLerQuantPreMerca.TabIndex = 8;
            this.btnLerQuantPreMerca.Text = "Ler Quant. e Preço Mercadorias";
            this.btnLerQuantPreMerca.UseVisualStyleBackColor = true;
            this.btnLerQuantPreMerca.Click += new System.EventHandler(this.btnLerQuantPreMerca_Click);
            // 
            // btnArray
            // 
            this.btnArray.Location = new System.Drawing.Point(160, 284);
            this.btnArray.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnArray.Name = "btnArray";
            this.btnArray.Size = new System.Drawing.Size(149, 76);
            this.btnArray.TabIndex = 7;
            this.btnArray.Text = "ArrayList";
            this.btnArray.UseVisualStyleBackColor = true;
            this.btnArray.Click += new System.EventHandler(this.btnArray_Click);
            // 
            // btnLerInverte
            // 
            this.btnLerInverte.Location = new System.Drawing.Point(160, 133);
            this.btnLerInverte.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLerInverte.Name = "btnLerInverte";
            this.btnLerInverte.Size = new System.Drawing.Size(149, 71);
            this.btnLerInverte.TabIndex = 6;
            this.btnLerInverte.Text = "Ler 20 números e inverter";
            this.btnLerInverte.UseVisualStyleBackColor = true;
            this.btnLerInverte.Click += new System.EventHandler(this.btnLerInverte_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(965, 555);
            this.Controls.Add(this.btnNomesPessoas);
            this.Controls.Add(this.btnVarialvelTotal);
            this.Controls.Add(this.btnMediaAlunos);
            this.Controls.Add(this.btnLerQuantPreMerca);
            this.Controls.Add(this.btnArray);
            this.Controls.Add(this.btnLerInverte);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNomesPessoas;
        private System.Windows.Forms.Button btnVarialvelTotal;
        private System.Windows.Forms.Button btnMediaAlunos;
        private System.Windows.Forms.Button btnLerQuantPreMerca;
        private System.Windows.Forms.Button btnArray;
        private System.Windows.Forms.Button btnLerInverte;
    }
}

