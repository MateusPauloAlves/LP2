﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnIsnumber_Click(object sender, EventArgs e)
        {
            int QntNumeros = 0;
            string a = rtbTexto.Text;
            char[] arr = a.ToCharArray();

            for(int i = 0; i < rtbTexto.Text.Length; i++)
            {
                if (char.IsNumber(arr[i]))
                    QntNumeros++;
            }
            MessageBox.Show("\nA quantidade de números é: " + QntNumeros);
        }

        private void btnPrimeiroBranco_Click(object sender, EventArgs e)
        {
            string a = rtbTexto.Text;
            int i = 0;

            while(i <= rtbTexto.Text.Length)
            {
                if (char.IsWhiteSpace(rtbTexto.Text, i))
                    break;
                i++;
            }
            MessageBox.Show("\nO primeiro espaço em branco é: " + i);
        }

        private void btnIsalpha_Click(object sender, EventArgs e)
        {
            int QntLetras = 0;
            string a = rtbTexto.Text;

            foreach(char bo in a)
            {
                if (char.IsLetter(bo))
                    QntLetras++;
            }
            MessageBox.Show("A quantidade de letras é " + QntLetras);
        }
    }
}
