﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnIsnumber_Click(object sender, EventArgs e)
        {
            int QntNumeros = 0;
            string a = rtbTexto.Text;
            char[] arr = a.ToCharArray();

            for(int i = 0; i < rtbTexto.Text.Length; i++)
            {
                if (char.IsNumber(arr[i]))
                    QntNumeros++;
            }
            rtbTexto.Text = rtbTexto.Text + "\nA quantidade de números é: " + QntNumeros;
        }

        private void btnPrimeiroBranco_Click(object sender, EventArgs e)
        {
            string a = rtbTexto.Text;
            int i = 0;

            while(i <= rtbTexto.Text.Length)
            {
                if (char.IsWhiteSpace(rtbTexto.Text, i))
                    break;
                i++;
            }
            rtbTexto.Text = rtbTexto.Text + "\nO primeiro espaço em branco é: " + i;
        }

        private void btnIsalpha_Click(object sender, EventArgs e)
        {
            int QntLetras = 0;
            string a = rtbTexto.Text;
            char[] arr = a.ToCharArray();

            for (int i = 0; i < rtbTexto.Text.Length; i++)
            {
                if (char.IsLetter(arr[i]))
                    QntLetras++;
            }
            rtbTexto.Text = rtbTexto.Text + "\nA quantidade de números é: " + QntLetras;
        }
    }
}
