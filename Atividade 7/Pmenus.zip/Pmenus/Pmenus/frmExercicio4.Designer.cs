﻿namespace Pmenus
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtbTexto = new System.Windows.Forms.RichTextBox();
            this.btnIsnumber = new System.Windows.Forms.Button();
            this.btnPrimeiroBranco = new System.Windows.Forms.Button();
            this.btnIsalpha = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtbTexto
            // 
            this.rtbTexto.Location = new System.Drawing.Point(49, 32);
            this.rtbTexto.Name = "rtbTexto";
            this.rtbTexto.Size = new System.Drawing.Size(582, 131);
            this.rtbTexto.TabIndex = 0;
            this.rtbTexto.Text = "";
            // 
            // btnIsnumber
            // 
            this.btnIsnumber.Location = new System.Drawing.Point(49, 205);
            this.btnIsnumber.Name = "btnIsnumber";
            this.btnIsnumber.Size = new System.Drawing.Size(152, 81);
            this.btnIsnumber.TabIndex = 1;
            this.btnIsnumber.Text = "Quantidade de Números";
            this.btnIsnumber.UseVisualStyleBackColor = true;
            this.btnIsnumber.Click += new System.EventHandler(this.btnIsnumber_Click);
            // 
            // btnPrimeiroBranco
            // 
            this.btnPrimeiroBranco.Location = new System.Drawing.Point(277, 205);
            this.btnPrimeiroBranco.Name = "btnPrimeiroBranco";
            this.btnPrimeiroBranco.Size = new System.Drawing.Size(152, 81);
            this.btnPrimeiroBranco.TabIndex = 2;
            this.btnPrimeiroBranco.Text = "Primeiro Branco";
            this.btnPrimeiroBranco.UseVisualStyleBackColor = true;
            this.btnPrimeiroBranco.Click += new System.EventHandler(this.btnPrimeiroBranco_Click);
            // 
            // btnIsalpha
            // 
            this.btnIsalpha.Location = new System.Drawing.Point(479, 205);
            this.btnIsalpha.Name = "btnIsalpha";
            this.btnIsalpha.Size = new System.Drawing.Size(152, 81);
            this.btnIsalpha.TabIndex = 3;
            this.btnIsalpha.Text = "Quantidade de Letras";
            this.btnIsalpha.UseVisualStyleBackColor = true;
            this.btnIsalpha.Click += new System.EventHandler(this.btnIsalpha_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(705, 440);
            this.Controls.Add(this.btnIsalpha);
            this.Controls.Add(this.btnPrimeiroBranco);
            this.Controls.Add(this.btnIsnumber);
            this.Controls.Add(this.rtbTexto);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtbTexto;
        private System.Windows.Forms.Button btnIsnumber;
        private System.Windows.Forms.Button btnPrimeiroBranco;
        private System.Windows.Forms.Button btnIsalpha;
    }
}