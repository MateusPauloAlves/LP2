﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int N1 = Convert.ToInt32(txtNumero1.Text);
            int N2 = Convert.ToInt32(txtNumero2.Text);

            Random random = new Random();
            if (N1 < N2)
            {
                int r = random.Next(N1, N2);
                MessageBox.Show("O número sorteado é" + r.ToString());
            }else
            {
                MessageBox.Show("O primeiro valor NÃO pode ser maior que o segundo!");
            }
        }
    }
}
