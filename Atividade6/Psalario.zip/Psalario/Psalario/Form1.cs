﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class lblNomeFunc : Form
    {
        public lblNomeFunc()
        {
            InitializeComponent();
        }

        private void btnValDados_Click(object sender, EventArgs e)
        {
            lblDados.Visible = true;

            double descontoINSS = 0;
            double descontoIRPF = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double numeroFilhos = 0;


            if (txtNomeFunc.Text == String.Empty) //testa vazio
            {
                MessageBox.Show("O nome do funcionário" + "\n não pode ser vazio!");
            }
            else
            {
                if (!double.TryParse(txtSalBruto.Text, out salarioBruto) ||
                    !double.TryParse(cbxNumFilhos.Text, out numeroFilhos))
                {
                    MessageBox.Show("Salário Bruto e Numéro de Filhos devem ser números inteiros, e válidos!");
                }
                else
                {
                    if (salarioBruto <= 0)
                        MessageBox.Show("Salário Bruto deve ser maior que 0!");

                    else
                    {
                        if (salarioBruto <= 800.47)
                        {
                            txtAliqINSS.Text = "7,65%";
                            descontoINSS = 0.0765 * salarioBruto;
                        }
                        else
                        {
                            if (salarioBruto <= 1050)
                            {
                                txtAliqINSS.Text = "8,65%";
                                descontoINSS = ((8.65 / 100) * salarioBruto);
                            }
                            else
                            {
                                if (salarioBruto <= 1400.77)
                                {
                                    txtAliqINSS.Text = "9,00%";
                                    descontoINSS = ((9.00 / 100) * salarioBruto);
                                }
                                else
                                {
                                    if (salarioBruto <= 2801.56)
                                    {
                                        txtAliqINSS.Text = "11,00%";
                                        descontoINSS = ((11.00 / 100) * salarioBruto);
                                    } 
                                    else
                                    {
                                        txtAliqINSS.Text = "308,17 (teto)";
                                        descontoINSS = 308.17;
                                    }

                                }
                            }
                        }

                        if(salarioBruto <= 1257.12)
                        {
                            txtAliqIRPF.Text = "isento do imposto";
                        }
                        else
                        {
                            if(salarioBruto <= 2512.08)
                            {
                                txtAliqIRPF.Text = "15,00%";
                                descontoIRPF = ((15.00/100) * salarioBruto);
                            }
                            else
                            {
                                txtAliqIRPF.Text = "27,5%";
                                descontoIRPF = ((27.5 / 100) * salarioBruto);
                            }
                        }

                        if(salarioBruto <= 435.52)
                        {
                            salarioFamilia = numeroFilhos * 22.33;
                        }
                        else
                        {
                            if(salarioBruto <= 654.61)
                            {
                                salarioFamilia = numeroFilhos * 15.74;
                            }
                            else
                            {
                                txtSalFamilia.Text = "Sem direito ao benefício";
                            }
                        }


                        salarioLiquido = (salarioBruto - descontoINSS - descontoIRPF + salarioFamilia) ;

                        txtSalFamilia.Text = Convert.ToString(salarioFamilia) + " R$";
                        txtDescINSS.Text = Convert.ToString(descontoINSS) + " R$";
                        txtDescIRPF.Text = Convert.ToString(descontoIRPF) + " R$";
                        txtSalLiq.Text = Convert.ToString(salarioLiquido) + " R$";
                    }
                }
            }

            

            if (rbtnM.Checked == true)
            {
                lblDados.Text = "Os descontos do salário do Sr." + txtNomeFunc.Text +
                    " que é " + (ckbxCasado.Checked == true ? "casado " : "solteiro ") +
                    "e que tem: " +
                    (cbxNumFilhos.SelectedIndex > 0 ? cbxNumFilhos.Text + " filho(s)" : "nenhum filho.");
            }
            else
            {
                lblDados.Text = "Os descontos do salário da Sra." + txtNomeFunc.Text +
                    " que é " + (ckbxCasado.Checked == true ? "casada " : "solteira ") +
                    "e que tem: " +
                    (cbxNumFilhos.SelectedIndex > 0 ? cbxNumFilhos.Text + " filho(s)" : "nenhum filho.");
            }
        }

        
    }
}         
