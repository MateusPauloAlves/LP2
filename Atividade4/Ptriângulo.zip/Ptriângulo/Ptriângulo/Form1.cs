﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriângulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValA.Clear();
            txtValB.Text = "";
            txtValC.Clear();
            txtResultado.Text = "";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double valorA, valorB, valorC;

            if(double.TryParse(txtValA.Text, out valorA) &&
               double.TryParse(txtValB.Text, out valorB) &&
               double.TryParse(txtValC.Text, out valorC))
            {
                if((Math.Abs(valorB - valorC) < valorA && valorA < valorB + valorC) 
                    && (Math.Abs(valorA-valorC) < valorB && valorB < valorA + valorC)
                    && (Math.Abs(valorA-valorB) < valorC && valorC < valorA + valorB))
                {
                    if(valorA == valorB && valorA == valorC)
                    {
                        txtResultado.Text = "Equilátero";
                    }
                    else{
                        if (valorA == valorB || valorA == valorC || valorB == valorC)
                        {
                            txtResultado.Text = "Isósceles";
                        }
                        else
                        {
                            txtResultado.Text = "Escaleno";
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Não é possível formar um triângulo com esses valores");
                }
            }
            else
            {
                MessageBox.Show("Algum valor está inválido");
                txtValA.Focus();
            }
        }
    }
}
