﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Text = "";
            txtImc.Text = string.Empty;
            txtSituacao.Text = string.Empty;

            txtPeso.Focus();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double Peso, Altura, IMC;

            if(double.TryParse(txtPeso.Text, out Peso) &&
                double.TryParse(txtAltura.Text, out Altura))
            {
                //IMC = Peso / (Altura * Altura);
                IMC = Peso / (Altura * Altura);
                txtImc.Text = IMC.ToString("N2");
            }
            else
            {
                MessageBox.Show("Valores Inválidos", "Erro o valor", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtPeso.Focus();
            }

            double.TryParse(txtImc.Text, out IMC);
            if (IMC < 18.5)
            {
                txtSituacao.Text = "Magreza";
                txtGrau.Text = "o";
            }
            if (IMC >= 18.5 && IMC <= 24.9)
            {
                txtSituacao.Text = "Normal";
                txtGrau.Text = "o";
            }
            if (IMC >= 25.0 && IMC <= 29.9)
            {
                txtSituacao.Text = "Sobrepeso";
                txtGrau.Text = "I";
            }
            if (IMC >= 30.0 && IMC <= 39.9)
            {
                txtSituacao.Text = "Obesidade";
                txtGrau.Text = "II";
            }
            if (IMC > 40.0)
            {
                txtSituacao.Text = "Obesidade Grave";
                txtGrau.Text = "III";
            }
        }
    }
}
